int fact(int val);
int func();

template <typename T> T abs(T i)
{
    return i >= 0 ? i : -i;
}
